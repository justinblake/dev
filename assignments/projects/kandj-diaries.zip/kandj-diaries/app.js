$('.navbar [data-toggle="dropdown"]').bootstrapDropdownHover({
 //none
});